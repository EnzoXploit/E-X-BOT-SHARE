"""
╔══════════════════════════════════════════════════╗
║          E-X Bot                                 ║
║          Developed by EnzoXploit                 ║
║          discord.py 2.7+ • Python 3.10+          ║
╚══════════════════════════════════════════════════╝
"""

import os
import asyncio
import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("TOKEN")
if not TOKEN:
    raise RuntimeError("TOKEN not found in .env — add TOKEN=your_bot_token to your .env file.")

# ── Intents ────────────────────────────────────────────────────
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

# ── Bot ────────────────────────────────────────────────────────
bot = commands.Bot(
    command_prefix="!",
    intents=intents,
    help_command=None,
    case_insensitive=True,
)

COGS = ["cogs.setup", "cogs.tickets", "cogs.utility", "cogs.welcome"]


_started = False


@bot.event
async def on_ready():
    # on_ready can fire again after a reconnect — only print/sync once
    global _started
    if _started:
        return
    _started = True
    print("=" * 52)
    print("  ███████╗███╗   ██╗███████╗ ██████╗ ")
    print("  ██╔════╝████╗  ██║╚══███╔╝██╔═══██╗")
    print("  █████╗  ██╔██╗ ██║  ███╔╝ ██║   ██║")
    print("  ██╔══╝  ██║╚██╗██║ ███╔╝  ██║   ██║")
    print("  ███████╗██║ ╚████║███████╗╚██████╔╝")
    print("  ╚══════╝╚═╝  ╚═══╝╚══════╝ ╚═════╝ ")
    print("        X P L O I T")
    print("=" * 52)
    print(f"  Bot      : {bot.user}")
    print(f"  ID       : {bot.user.id}")
    print(f"  Servers  : {len(bot.guilds)}")
    print(f"  Dev      : EnzoXploit")
    print(f"  Brand    : E-X")
    print("=" * 52)
    try:
        synced = await bot.tree.sync()
        print(f"  Synced {len(synced)} slash command(s)")
    except Exception as e:
        print(f"  Slash sync failed: {e}")
    print("=" * 52)


async def main():
    async with bot:
        for cog in COGS:
            try:
                await bot.load_extension(cog)
                print(f"  ✅ Loaded: {cog}")
            except Exception as e:
                print(f"  ❌ Failed: {cog} — {e}")
        await bot.start(TOKEN)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n  E-X stopped.")
