"""
Branding — E-X (EnzoXploit)

Footers:  ticket system → 'E-X Ticketing • Powered by EnzoXploit'
          welcome system → 'E-X Welcoming • Powered by EnzoXploit'
          everything else → 'E-X • Powered by EnzoXploit'

One place for the footer used by every panel, log, DM and info message.
"""
from __future__ import annotations

import discord

BRAND   = "E-X"
POWERED = "Powered by EnzoXploit"
TICKETING = "E-X Ticketing"
WELCOMING = "E-X Welcoming"
FOOTER_TEXT = f"{BRAND} • {POWERED}"


def footer_item(extra: str = "", brand: str = BRAND) -> discord.ui.TextDisplay:
    """Footer line: '-# E-X • Powered by EnzoXploit'.
    `extra` is optional additional small text shown above the brand line."""
    line = f"{brand} • {POWERED}"
    text = f"-# {extra}\n-# {line}" if extra else f"-# {line}"
    return discord.ui.TextDisplay(text)


def add_footer(container: discord.ui.Container, extra: str = "", brand: str = BRAND) -> None:
    container.add_item(discord.ui.Separator())
    container.add_item(footer_item(extra, brand))
