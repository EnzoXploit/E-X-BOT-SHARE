"""
Utility cog — /say and /announce
E-X

Both commands can ping @everyone, @here, a role, or any user/role typed
into the message. Pings are only possible for members with the
"Manage Server" permission.
"""
from __future__ import annotations

from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.branding import add_footer

ANNOUNCE_COLOR = 0x000000

PING_CHOICES = [
    app_commands.Choice(name="@everyone", value="everyone"),
    app_commands.Choice(name="@here",     value="here"),
    app_commands.Choice(name="No ping",   value="none"),
]


# ── Helpers ────────────────────────────────────────────────────

def _is_staff(interaction: discord.Interaction) -> bool:
    perms = interaction.permissions
    return perms.manage_guild or perms.administrator


def _build_ping(ping: Optional[str], role: Optional[discord.Role]) -> str:
    """Builds the mention string that goes in front of the message."""
    parts: list[str] = []
    if ping == "everyone":
        parts.append("@everyone")
    elif ping == "here":
        parts.append("@here")
    if role is not None:
        # @everyone "role" is the guild default role — its mention is "@everyone"
        parts.append("@everyone" if role.is_default() else role.mention)
    return " ".join(dict.fromkeys(parts))  # de-duplicate, keep order


def _mentions() -> discord.AllowedMentions:
    # The caller is already permission-checked, so let every mention in the
    # message actually ping (Discord still enforces the bot's own perms).
    return discord.AllowedMentions(everyone=True, roles=True, users=True, replied_user=False)


def _text_channel_check(interaction: discord.Interaction,
                        channel: discord.abc.GuildChannel) -> Optional[str]:
    me = interaction.guild.me
    perms = channel.permissions_for(me)
    if not perms.view_channel or not perms.send_messages:
        return f"I can't send messages in {channel.mention}."
    return None


# ── Announce modal ─────────────────────────────────────────────

class AnnounceModal(discord.ui.Modal, title="Create Announcement"):
    title_input = discord.ui.TextInput(
        label="Title",
        placeholder="Announcement title",
        max_length=100,
        required=True,
    )
    body_input = discord.ui.TextInput(
        label="Message",
        style=discord.TextStyle.paragraph,
        placeholder="Write your announcement here. New lines are supported.",
        max_length=3000,
        required=True,
    )

    def __init__(self, channel: discord.abc.Messageable, ping_text: str,
                 image: Optional[discord.Attachment], author: discord.Member):
        super().__init__()
        self.channel = channel
        self.ping_text = ping_text
        self.image = image
        self.author = author

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        view = discord.ui.LayoutView()
        container = discord.ui.Container(accent_color=ANNOUNCE_COLOR)
        container.add_item(discord.ui.TextDisplay(f"# {self.title_input.value}"))
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay(self.body_input.value))

        files: list[discord.File] = []
        if self.image is not None:
            file = await self.image.to_file()
            files.append(file)
            container.add_item(discord.ui.Separator())
            container.add_item(discord.ui.MediaGallery(
                discord.MediaGalleryItem(f"attachment://{file.filename}")
            ))

        add_footer(container, extra=f"Announced by {self.author.display_name}")

        # Components V2 messages have no "content" field, so the ping goes in
        # its own text component above the container.
        if self.ping_text:
            view.add_item(discord.ui.TextDisplay(self.ping_text))
        view.add_item(container)

        try:
            msg = await self.channel.send(
                view=view, files=files, allowed_mentions=_mentions()
            )
        except discord.Forbidden:
            return await interaction.followup.send(
                f"❌ I don't have permission to send messages in {self.channel.mention}.",
                ephemeral=True,
            )
        except discord.HTTPException as e:
            return await interaction.followup.send(f"❌ Failed to send: {e}", ephemeral=True)

        # Auto-publish if it's an announcement (news) channel
        if getattr(self.channel, "type", None) == discord.ChannelType.news:
            try:
                await msg.publish()
            except discord.HTTPException:
                pass

        await interaction.followup.send(
            f"✅ Announcement sent in {self.channel.mention} — [jump to message]({msg.jump_url})",
            ephemeral=True,
        )

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        msg = f"❌ Something went wrong: {error}"
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)


# ── Cog ────────────────────────────────────────────────────────

class UtilityCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # /say ------------------------------------------------------
    @app_commands.command(name="say", description="Make the bot send a message (with optional ping)")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(
        message="What the bot should say (use \\n for a new line)",
        channel="Channel to send it in (default: this channel)",
        ping="Ping @everyone or @here",
        role="Ping a specific role",
    )
    @app_commands.choices(ping=PING_CHOICES)
    async def say_cmd(
        self,
        interaction: discord.Interaction,
        message: str,
        channel: Optional[discord.TextChannel] = None,
        ping: Optional[app_commands.Choice[str]] = None,
        role: Optional[discord.Role] = None,
    ):
        if not _is_staff(interaction):
            return await interaction.response.send_message(
                "❌ You need the **Manage Server** permission to use this.", ephemeral=True
            )

        target = channel or interaction.channel
        problem = _text_channel_check(interaction, target)
        if problem:
            return await interaction.response.send_message(f"❌ {problem}", ephemeral=True)

        text = message.replace("\\n", "\n")
        ping_text = _build_ping(ping.value if ping else None, role)
        content = f"{ping_text}\n{text}" if ping_text else text

        if len(content) > 2000:
            return await interaction.response.send_message(
                "❌ Message is too long (max 2000 characters including pings).", ephemeral=True
            )

        try:
            sent = await target.send(content, allowed_mentions=_mentions())
        except discord.HTTPException as e:
            return await interaction.response.send_message(f"❌ Failed to send: {e}", ephemeral=True)

        await interaction.response.send_message(
            f"✅ Sent in {target.mention} — [jump to message]({sent.jump_url})", ephemeral=True
        )

    # /announce -------------------------------------------------
    @app_commands.command(name="announce", description="Send a styled announcement (with optional ping)")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(
        channel="Channel to announce in (default: this channel)",
        ping="Ping @everyone or @here",
        role="Ping a specific role",
        image="Optional image to attach to the announcement",
    )
    @app_commands.choices(ping=PING_CHOICES)
    async def announce_cmd(
        self,
        interaction: discord.Interaction,
        channel: Optional[discord.TextChannel] = None,
        ping: Optional[app_commands.Choice[str]] = None,
        role: Optional[discord.Role] = None,
        image: Optional[discord.Attachment] = None,
    ):
        if not _is_staff(interaction):
            return await interaction.response.send_message(
                "❌ You need the **Manage Server** permission to use this.", ephemeral=True
            )

        target = channel or interaction.channel
        problem = _text_channel_check(interaction, target)
        if problem:
            return await interaction.response.send_message(f"❌ {problem}", ephemeral=True)

        if image is not None and not (image.content_type or "").startswith("image/"):
            return await interaction.response.send_message(
                "❌ The attachment must be an image.", ephemeral=True
            )

        ping_text = _build_ping(ping.value if ping else None, role)
        await interaction.response.send_modal(
            AnnounceModal(target, ping_text, image, interaction.user)
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(UtilityCog(bot))
