"""
Welcome cog — /welcome setup | test | status | disable
E-X • Powered by EnzoXploit

Placeholders you can use in the title / message:
  {user}      mention of the new member
  {username}  their display name
  {server}    server name
  {count}     member count (e.g. 128)
"""
from __future__ import annotations

from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.branding import WELCOMING, add_footer
from utils.store import get_welcome, set_welcome

WELCOME_COLOR = 0x000000
DEFAULT_TITLE = "Welcome to {server}!"
DEFAULT_MESSAGE = (
    "Hey {user}, glad to have you here! 🎉\n"
    "You are member **#{count}**. Read the rules and enjoy your stay."
)


def _fmt(text: str, member: discord.Member) -> str:
    return (
        text.replace("{user}", member.mention)
            .replace("{username}", member.display_name)
            .replace("{server}", member.guild.name)
            .replace("{count}", str(member.guild.member_count or 0))
    )


def build_welcome_view(cfg: dict, member: discord.Member) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    if cfg.get("ping_user", True):
        # Components V2 has no message "content", so the ping is its own text component.
        view.add_item(discord.ui.TextDisplay(member.mention))

    container = discord.ui.Container(accent_color=WELCOME_COLOR)
    title = _fmt(cfg.get("title") or DEFAULT_TITLE, member)
    body = _fmt(cfg.get("message") or DEFAULT_MESSAGE, member)
    container.add_item(discord.ui.Section(
        discord.ui.TextDisplay(f"## {title}\n{body}"),
        accessory=discord.ui.Thumbnail(member.display_avatar.url),
    ))
    if cfg.get("image_url"):
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.MediaGallery(discord.MediaGalleryItem(cfg["image_url"])))
    add_footer(container, brand=WELCOMING)
    view.add_item(container)
    return view


class WelcomeModal(discord.ui.Modal, title="Welcome Message"):
    title_input = discord.ui.TextInput(
        label="Title", max_length=100, required=True, default=DEFAULT_TITLE,
    )
    message_input = discord.ui.TextInput(
        label="Message  ({user} {username} {server} {count})",
        style=discord.TextStyle.paragraph, max_length=1500, required=True,
        default=DEFAULT_MESSAGE,
    )

    def __init__(self, channel: discord.TextChannel, role: Optional[discord.Role],
                 image_url: str, ping_user: bool, existing: dict):
        super().__init__()
        self.channel = channel
        self.role = role
        self.image_url = image_url
        self.ping_user = ping_user
        if existing.get("title"):
            self.title_input.default = existing["title"]
        if existing.get("message"):
            self.message_input.default = existing["message"]

    async def on_submit(self, interaction: discord.Interaction):
        cfg = {
            "enabled": True,
            "channel_id": self.channel.id,
            "role_id": self.role.id if self.role else None,
            "image_url": self.image_url,
            "ping_user": self.ping_user,
            "title": self.title_input.value,
            "message": self.message_input.value,
        }
        set_welcome(interaction.guild.id, cfg)
        lines = [
            "✅ **Welcome system is on!**",
            f"**Channel:** {self.channel.mention}",
            f"**Auto-role:** {self.role.mention if self.role else 'None'}",
            f"**Ping new member:** {'Yes' if self.ping_user else 'No'}",
            f"**Image:** {'Set' if self.image_url else 'None'}",
            "",
            "Use `/welcome test` to preview it.",
        ]
        if self.role:
            me = interaction.guild.me
            if self.role.managed or self.role >= me.top_role:
                lines.append("⚠️ I can't give that role — move my role **above** it in Server Settings → Roles.")
        await interaction.response.send_message("\n".join(lines), ephemeral=True)


class WelcomeCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    welcome = app_commands.Group(
        name="welcome",
        description="Set up the welcome message for new members",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    @staticmethod
    def _allowed(interaction: discord.Interaction) -> bool:
        p = interaction.permissions
        return p.manage_guild or p.administrator

    @welcome.command(name="setup", description="Set up or edit the welcome message")
    @app_commands.describe(
        channel="Channel where welcome messages are sent",
        role="Role to give new members automatically (optional)",
        image_url="Banner image link shown in the welcome message (optional)",
        ping_user="Ping the new member (default: yes)",
    )
    async def setup_cmd(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        role: Optional[discord.Role] = None,
        image_url: Optional[str] = None,
        ping_user: bool = True,
    ):
        if not self._allowed(interaction):
            return await interaction.response.send_message(
                "❌ You need the **Manage Server** permission.", ephemeral=True)
        perms = channel.permissions_for(interaction.guild.me)
        if not (perms.view_channel and perms.send_messages):
            return await interaction.response.send_message(
                f"❌ I can't send messages in {channel.mention}.", ephemeral=True)
        if image_url and not image_url.startswith(("http://", "https://")):
            return await interaction.response.send_message(
                "❌ Image link must start with `http://` or `https://`.", ephemeral=True)
        existing = get_welcome(interaction.guild.id) or {}
        await interaction.response.send_modal(
            WelcomeModal(channel, role, image_url or "", ping_user, existing))

    @welcome.command(name="test", description="Preview the welcome message with yourself")
    async def test_cmd(self, interaction: discord.Interaction):
        if not self._allowed(interaction):
            return await interaction.response.send_message(
                "❌ You need the **Manage Server** permission.", ephemeral=True)
        cfg = get_welcome(interaction.guild.id)
        if not cfg:
            return await interaction.response.send_message(
                "❌ Run `/welcome setup` first.", ephemeral=True)
        cfg = {**cfg, "ping_user": False}  # preview shouldn't ping you
        await interaction.response.send_message(
            view=build_welcome_view(cfg, interaction.user), ephemeral=True)

    @welcome.command(name="status", description="Show the current welcome settings")
    async def status_cmd(self, interaction: discord.Interaction):
        if not self._allowed(interaction):
            return await interaction.response.send_message(
                "❌ You need the **Manage Server** permission.", ephemeral=True)
        cfg = get_welcome(interaction.guild.id)
        if not cfg:
            return await interaction.response.send_message(
                "Welcome is **not set up**. Use `/welcome setup`.", ephemeral=True)
        ch = interaction.guild.get_channel(cfg.get("channel_id") or 0)
        role = interaction.guild.get_role(cfg.get("role_id") or 0)
        await interaction.response.send_message(
            f"**Welcome:** {'On' if cfg.get('enabled') else 'Off'}\n"
            f"**Channel:** {ch.mention if ch else 'not found'}\n"
            f"**Auto-role:** {role.mention if role else 'None'}\n"
            f"**Ping new member:** {'Yes' if cfg.get('ping_user', True) else 'No'}\n"
            f"**Image:** {'Set' if cfg.get('image_url') else 'None'}",
            ephemeral=True)

    @welcome.command(name="disable", description="Turn the welcome message off")
    async def disable_cmd(self, interaction: discord.Interaction):
        if not self._allowed(interaction):
            return await interaction.response.send_message(
                "❌ You need the **Manage Server** permission.", ephemeral=True)
        cfg = get_welcome(interaction.guild.id)
        if not cfg:
            return await interaction.response.send_message(
                "Welcome is not set up.", ephemeral=True)
        cfg["enabled"] = False
        set_welcome(interaction.guild.id, cfg)
        await interaction.response.send_message(
            "✅ Welcome turned off. `/welcome setup` turns it back on.", ephemeral=True)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.bot:
            return
        cfg = get_welcome(member.guild.id)
        if not cfg or not cfg.get("enabled"):
            return

        role = member.guild.get_role(cfg.get("role_id") or 0)
        if role:
            try:
                await member.add_roles(role, reason="E-X welcome auto-role")
            except discord.HTTPException:
                pass

        channel = member.guild.get_channel(cfg.get("channel_id") or 0)
        if not channel:
            return
        try:
            await channel.send(
                view=build_welcome_view(cfg, member),
                allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False),
            )
        except discord.HTTPException:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(WelcomeCog(bot))
