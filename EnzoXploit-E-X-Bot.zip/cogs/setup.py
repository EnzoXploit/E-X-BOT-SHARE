from __future__ import annotations
import discord
from discord import app_commands
from discord.ext import commands
from utils.store import get_config, set_config

# ── Custom Emojis ──────────────────────────────────────────────
E_SUCCESS  = "✅"
E_CROSS    = "❌"
E_INFO     = "ℹ️"
E_WARN     = "⚠️"
E_TICKET   = "🎫"
E_BUG      = "🐛"
E_CLAIM    = "🙋"
E_VIEW     = "👁️"
E_REOPEN   = "🔓"
E_QUESTION = "❓"
E_DELETE   = "🗑️"
E_SETUP    = "⚙️"
E_CUSTOM   = "✏️"

# ── Colors ─────────────────────────────────────────────────────
# All container accent bars + backgrounds are pure black, regardless of
# message type (success/error/info/warn all look the same now).
EMBED_COLOR   = 0x000000
SUCCESS_COLOR = 0x000000
ERROR_COLOR   = 0x000000
WARN_COLOR    = 0x000000
INFO_COLOR    = 0x000000

BRAND_FULL = "E-X Ticketing • Powered by EnzoXploit"

DEFAULT_BANNER = ""  # no default banner

DEFAULT_CATEGORIES = ["General Support", "Giveaway Claim", "Bug Report", "Other"]

COLOR_OPTIONS = ["Blue", "Green", "Red", "Grey", "Yellow"]

BUTTON_COLOR_MAP = {
    "Green":  discord.ButtonStyle.success,
    "Blue":   discord.ButtonStyle.primary,
    "Grey":   discord.ButtonStyle.secondary,
    "Yellow": discord.ButtonStyle.secondary,
    "Red":    discord.ButtonStyle.danger,
}

# Colour options for the optional Panel Text button. Discord only has 5
# real non-link button styles (Blurple, Grey, Green, Red — Yellow has no
# native style). Black/White/Yellow all render as Discord's grey button
# since there's no native style for them; labelled honestly in the picker
# so admins know what they'll actually get.
PANEL_BUTTON_COLOR_OPTIONS = ["Grey", "Yellow", "Blue", "Red", "Black", "White"]

PANEL_BUTTON_COLOR_MAP = {
    "Grey":   discord.ButtonStyle.secondary,
    "Yellow": discord.ButtonStyle.secondary,
    "Blue":   discord.ButtonStyle.primary,
    "Red":    discord.ButtonStyle.danger,
    "Black":  discord.ButtonStyle.secondary,
    "White":  discord.ButtonStyle.secondary,
}

CATEGORY_EMOJIS = {
    "General Support": E_QUESTION,
    "Giveaway Claim":  E_TICKET,
    "Bug Report":      E_BUG,
    "Other":           E_CUSTOM,
}


# ── Shared State ───────────────────────────────────────────────

class SetupState:
    def __init__(self):
        self.support_role: discord.Role | None               = None
        self.panel_channel: discord.TextChannel | None       = None
        self.ticket_category: discord.CategoryChannel | None = None
        self.log_channel: discord.TextChannel | None         = None
        self.ticket_limit: int       = 3
        self.panel_title: str        = "Support Center"
        self.panel_description: str  = "Click a button below to open a ticket."
        # Pre-filled defaults — server name/icon resolved at finish time
        self.author_name: str        = ""          # filled at finish with guild.name
        self.author_icon_url: str    = ""          # filled at finish with guild.icon
        self.footer_text: str        = "E-X"
        self.footer_icon_url: str    = ""          # bot avatar, resolved at finish
        self.thumbnail_url: str      = ""          # guild icon, resolved at finish
        self.image_url: str          = DEFAULT_BANNER
        self.button_label: str       = "Open a Ticket"
        self.button_emoji: str       = ""
        # Per-button colours: key = category name or "main"
        self.button_colors: dict[str, str] = {"main": "Blue"}
        # Nothing preselected: /setup starts with just the "Open a Ticket"
        # button. /setup2 (dropdown) fills in the defaults itself because a
        # dropdown can't be empty.
        self.active_categories: list[str] = []
        # Per-button extras: {"Name": {"label": "...", "emoji": "..."}}
        self.category_meta: dict[str, dict] = {}
        # Whether the main "Open a Ticket" button is shown on the button
        # panel. Category buttons remain the only way to open tickets if
        # this is turned off — guarded so it can never be turned off when
        # there are zero categories left (and vice versa).
        self.show_main_button: bool  = True   # kept for old configs; the panel now shows the main button only when there are no category buttons
        # Track whether user explicitly edited author/footer/thumbnail
        # so we know not to overwrite at finish if they cleared them
        self._author_edited: bool    = False
        self._footer_edited: bool    = False
        self._thumb_edited: bool     = False

    def resolved_author_name(self, guild: discord.Guild) -> str:
        if self._author_edited:
            return self.author_name
        return self.author_name or guild.name

    def resolved_author_icon(self, guild: discord.Guild) -> str:
        if self._author_edited:
            return self.author_icon_url
        return self.author_icon_url or (guild.icon.url if guild.icon else "")

    def resolved_footer_icon(self, bot: discord.Client) -> str:
        if self._footer_edited:
            return self.footer_icon_url
        return self.footer_icon_url or (bot.user.display_avatar.url if bot.user else "")

    def resolved_thumbnail(self, guild: discord.Guild) -> str:
        if self._thumb_edited:
            return self.thumbnail_url
        return self.thumbnail_url or (guild.icon.url if guild.icon else "")


# ── Components V2 Helpers ───────────────────────────────────────

class MessageLayout(discord.ui.LayoutView):
    """Generic single-container layout for simple text replies."""
    def __init__(self, text: str, color: int, *, extra_rows: list[discord.ui.ActionRow] | None = None):
        super().__init__()
        container = discord.ui.Container(accent_color=color)
        container.add_item(discord.ui.TextDisplay(text))
        self.add_item(container)
        for row in (extra_rows or []):
            self.add_item(row)


def _ok(msg: str) -> MessageLayout:
    return MessageLayout(f"{E_SUCCESS}  {msg}", SUCCESS_COLOR)

def _ok_raw(text: str) -> MessageLayout:
    """Like _ok but takes pre-formatted text (e.g. with its own heading)."""
    return MessageLayout(text, SUCCESS_COLOR)

def _err(msg: str) -> MessageLayout:
    return MessageLayout(f"{E_CROSS}  {msg}", ERROR_COLOR)

def _info(msg: str) -> MessageLayout:
    return MessageLayout(f"{E_INFO}  {msg}", INFO_COLOR)


# ── Modals ─────────────────────────────────────────────────────

class PanelTextModal(discord.ui.Modal, title="Panel Text Settings"):
    panel_title = discord.ui.TextInput(
        label="Panel Title",
        placeholder="e.g. Support Center",
        max_length=100,
    )
    panel_description = discord.ui.TextInput(
        label="Panel Description",
        style=discord.TextStyle.paragraph,
        placeholder="Click a button below to open a ticket.",
        max_length=300,
        required=False,
    )
    author_name = discord.ui.TextInput(
        label="Author Name  (blank = server name)",
        placeholder="Defaults to your server name",
        required=False,
        max_length=100,
    )
    author_icon_url = discord.ui.TextInput(
        label="Author Icon URL  (blank = server icon)",
        placeholder="Defaults to your server icon",
        required=False,
        max_length=500,
    )

    def __init__(self, state: SetupState):
        super().__init__()
        self.state = state
        self.panel_title.default       = state.panel_title
        self.panel_description.default = state.panel_description
        self.author_name.default       = state.author_name
        self.author_icon_url.default   = state.author_icon_url

    async def on_submit(self, interaction: discord.Interaction):
        self.state.panel_title       = self.panel_title.value
        self.state.panel_description = self.panel_description.value
        self.state.author_name       = self.author_name.value
        self.state.author_icon_url   = self.author_icon_url.value
        self.state._author_edited    = True
        await interaction.response.send_message(
            view=_ok("Panel text updated."), ephemeral=True
        )


class FooterMediaModal(discord.ui.Modal, title="Footer, Thumbnail & Banner"):
    footer_text = discord.ui.TextInput(
        label="Footer Text  (blank = 'E-X')",
        placeholder="E-X",
        required=False,
        max_length=200,
    )
    footer_icon_url = discord.ui.TextInput(
        label="Footer Icon URL  (blank = bot avatar)",
        placeholder="Defaults to bot avatar",
        required=False,
        max_length=500,
    )
    thumbnail_url = discord.ui.TextInput(
        label="Thumbnail URL  (blank = server icon)",
        placeholder="Defaults to your server icon",
        required=False,
        max_length=500,
    )
    image_url = discord.ui.TextInput(
        label="Banner Image URL  (optional)",
        placeholder="Leave blank for no banner",
        required=False,
        max_length=500,
    )

    def __init__(self, state: SetupState):
        super().__init__()
        self.state = state
        self.footer_text.default     = state.footer_text
        self.footer_icon_url.default = state.footer_icon_url
        self.thumbnail_url.default   = state.thumbnail_url
        self.image_url.default       = state.image_url

    async def on_submit(self, interaction: discord.Interaction):
        self.state.footer_text     = self.footer_text.value or "E-X"
        self.state.footer_icon_url = self.footer_icon_url.value
        self.state.thumbnail_url   = self.thumbnail_url.value
        self.state.image_url       = self.image_url.value or DEFAULT_BANNER
        self.state._footer_edited  = True
        self.state._thumb_edited   = True
        await interaction.response.send_message(
            view=_ok("Footer, thumbnail and banner updated."), ephemeral=True
        )


class ButtonLabelModal(discord.ui.Modal, title="Main Button Settings"):
    button_label = discord.ui.TextInput(
        label="Button Label",
        placeholder="e.g. Open a Ticket",
        default="Open a Ticket",
        max_length=80,
    )
    button_emoji = discord.ui.TextInput(
        label="Button Emoji",
        placeholder="Leave blank for default ticket emoji",
        required=False,
        max_length=100,
    )

    def __init__(self, state: SetupState):
        super().__init__()
        self.state = state
        self.button_label.default = state.button_label
        self.button_emoji.default = state.button_emoji

    async def on_submit(self, interaction: discord.Interaction):
        self.state.button_label = self.button_label.value
        self.state.button_emoji = self.button_emoji.value
        await interaction.response.send_message(
            view=_ok("Button settings updated."), ephemeral=True
        )


class AddCategoryModal(discord.ui.Modal, title="Add Button"):
    cat_name = discord.ui.TextInput(
        label="Name  (ticket category)",
        placeholder="e.g. Partnership Request",
        max_length=80,
    )
    cat_label = discord.ui.TextInput(
        label="Button Label  (blank = same as name)",
        placeholder="e.g. Partnership",
        max_length=80,
        required=False,
    )
    cat_emoji = discord.ui.TextInput(
        label="Emoji  (optional)",
        placeholder="e.g. 🤝",
        max_length=64,
        required=False,
    )
    cat_color = discord.ui.TextInput(
        label="Colour  (Blue / Green / Red / Grey)",
        placeholder="Grey",
        max_length=10,
        required=False,
    )

    def __init__(self, state: SetupState, *, dropdown: bool = False):
        super().__init__()
        self.state    = state
        self.dropdown = dropdown
        if dropdown:
            # Dropdown options have no colour
            self.remove_item(self.cat_color)

    async def on_submit(self, interaction: discord.Interaction):
        name  = self.cat_name.value.strip()
        label = self.cat_label.value.strip()
        emoji = self.cat_emoji.value.strip()
        color = (self.cat_color.value.strip().title() if not self.dropdown else "") or "Grey"

        if not name:
            return await interaction.response.send_message(
                view=_err("Name cannot be empty."), ephemeral=True
            )
        if name in self.state.active_categories:
            return await interaction.response.send_message(
                view=_err(f"**{name}** already exists."), ephemeral=True
            )
        max_items = 10 if self.dropdown else 9
        if len(self.state.active_categories) >= max_items:
            return await interaction.response.send_message(
                view=_err(f"Maximum {max_items} buttons allowed."),
                ephemeral=True,
            )
        if emoji and emoji.isascii() and not emoji.startswith("<"):
            return await interaction.response.send_message(
                view=_err("That doesn't look like an emoji — paste a real emoji like 🤝 (or leave it blank)."),
                ephemeral=True,
            )
        if color not in COLOR_OPTIONS:
            return await interaction.response.send_message(
                view=_err(f"Colour must be one of: {', '.join(COLOR_OPTIONS)}."), ephemeral=True
            )

        self.state.active_categories.append(name)
        self.state.button_colors[name] = color
        self.state.category_meta[name] = {"label": label or name, "emoji": emoji}

        await interaction.response.edit_message(
            view=SetupStep2Layout(self.state, dropdown=self.dropdown)
        )


# ── Add Button: Custom / Templates chooser ─────────────────────

# Ready-made buttons the admin can add in one click.
# name -> (emoji, default colour)
BUTTON_TEMPLATES: dict[str, tuple[str, str]] = {
    "General Support":   (E_QUESTION, "Grey"),
    "Giveaway Claim":    (E_TICKET,   "Green"),
    "Bug Report":        (E_BUG,      "Red"),
    "Other":             (E_CUSTOM,   "Grey"),
    "Partnership":       ("🤝",       "Blue"),
    "Staff Application": ("📝",       "Green"),
    "Appeal":            ("⚖️",       "Grey"),
}


class AddButtonChoiceView(discord.ui.LayoutView):
    """Shown when 'Add Button' is pressed: build a custom button, or pick
    from ready-made templates."""
    def __init__(self, state: SetupState, *, dropdown: bool = False):
        super().__init__(timeout=300)
        self.state    = state
        self.dropdown = dropdown

        container = discord.ui.Container(accent_color=INFO_COLOR)
        container.add_item(discord.ui.TextDisplay(
            f"## {E_SUCCESS}  Add Button\n"
            f"> {E_CUSTOM}  **Custom Button** — pick your own name, label, emoji"
            f"{'' if dropdown else ' and colour'}\n"
            f"> {E_TICKET}  **Templates** — add ready-made buttons like General Support, "
            f"Giveaway Claim, Bug Report, Other"
        ))
        row = discord.ui.ActionRow()

        custom_btn = discord.ui.Button(label="Custom Button", style=discord.ButtonStyle.primary, emoji=E_CUSTOM)
        custom_btn.callback = self._custom_cb
        row.add_item(custom_btn)

        tpl_btn = discord.ui.Button(label="Templates", style=discord.ButtonStyle.primary, emoji=E_TICKET)
        tpl_btn.callback = self._templates_cb
        row.add_item(tpl_btn)

        back_btn = discord.ui.Button(label="◀ Back", style=discord.ButtonStyle.secondary, emoji=E_REOPEN)
        back_btn.callback = self._back_cb
        row.add_item(back_btn)
        container.add_item(row)
        self.add_item(container)

    async def _custom_cb(self, interaction: discord.Interaction):
        await interaction.response.send_modal(AddCategoryModal(self.state, dropdown=self.dropdown))

    async def _templates_cb(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            view=TemplatePickView(self.state, dropdown=self.dropdown)
        )

    async def _back_cb(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            view=SetupStep2Layout(self.state, dropdown=self.dropdown)
        )


class TemplateSelect(discord.ui.Select):
    def __init__(self, state: SetupState, available: list[str], *, dropdown: bool):
        self.state    = state
        self.dropdown = dropdown
        super().__init__(
            placeholder="Select templates to add…",
            min_values=1,
            max_values=len(available),
            options=[
                discord.SelectOption(label=name, value=name, emoji=BUTTON_TEMPLATES[name][0])
                for name in available
            ],
        )

    async def callback(self, interaction: discord.Interaction):
        max_items = 10 if self.dropdown else 9
        room = max_items - len(self.state.active_categories)
        chosen = [n for n in self.values if n not in self.state.active_categories]
        if len(chosen) > room:
            return await interaction.response.send_message(
                view=_err(
                    f"Only {max(room, 0)} more button(s) fit (maximum {max_items}). "
                    f"Pick fewer templates or remove a button first."
                ),
                ephemeral=True,
            )
        for name in chosen:
            emoji, color = BUTTON_TEMPLATES[name]
            self.state.active_categories.append(name)
            self.state.button_colors[name] = color
            self.state.category_meta[name] = {"label": name, "emoji": emoji}

        await interaction.response.edit_message(
            view=SetupStep2Layout(self.state, dropdown=self.dropdown)
        )


class TemplatePickView(discord.ui.LayoutView):
    def __init__(self, state: SetupState, *, dropdown: bool = False):
        super().__init__(timeout=300)
        self.state    = state
        self.dropdown = dropdown

        available = [n for n in BUTTON_TEMPLATES if n not in state.active_categories]
        container = discord.ui.Container(accent_color=INFO_COLOR)
        if available:
            container.add_item(discord.ui.TextDisplay(
                f"## {E_TICKET}  Templates\nSelect one or more, they are added with a ready-made "
                f"label, emoji{'' if dropdown else ' and colour'}."
            ))
            row = discord.ui.ActionRow()
            row.add_item(TemplateSelect(state, available, dropdown=dropdown))
            container.add_item(row)
        else:
            container.add_item(discord.ui.TextDisplay(
                f"{E_INFO}  All templates are already added."
            ))

        back_row = discord.ui.ActionRow()
        back_btn = discord.ui.Button(label="◀ Back", style=discord.ButtonStyle.secondary, emoji=E_REOPEN)
        back_btn.callback = self._back_cb
        back_row.add_item(back_btn)
        container.add_item(back_row)
        self.add_item(container)

    async def _back_cb(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            view=AddButtonChoiceView(self.state, dropdown=self.dropdown)
        )


# ── Button Categories: which Discord category each button opens tickets in ──

def _btn_label(state: SetupState, name: str) -> str:
    return state.category_meta.get(name, {}).get("label") or name


def _btn_target(state: SetupState, name: str) -> str:
    cid = state.category_meta.get(name, {}).get("category_id")
    return f"<#{cid}>" if cid else "default"


class ButtonCategoryView(discord.ui.LayoutView):
    """Pick a Discord category per button, e.g. General -> 'General Tickets',
    Bug Report -> 'Bug Tickets'. Buttons without one use the default Ticket Category."""
    def __init__(self, state: SetupState, *, dropdown: bool = False, notice: str = ""):
        super().__init__(timeout=300)
        self.state    = state
        self.dropdown = dropdown

        default = state.ticket_category.mention if state.ticket_category else "the Ticket Category"
        lines = [
            f"## {E_VIEW}  Button Categories",
            "Choose the Discord category each button's tickets are created in.",
            f"Buttons without one use the default: {default}\n",
        ]
        if state.active_categories:
            for name in state.active_categories:
                lines.append(f"> **{_btn_label(state, name)}** → {_btn_target(state, name)}")
        else:
            lines.append(f"{E_INFO}  Add a button first (use **Add Button**), then come back here.")
        if notice:
            lines.append(f"\n{notice}")

        container = discord.ui.Container(accent_color=INFO_COLOR)
        container.add_item(discord.ui.TextDisplay("\n".join(lines)))

        if state.active_categories:
            row = discord.ui.ActionRow()
            row.add_item(ButtonCategoryPicker(state, dropdown=dropdown))
            container.add_item(row)

        btn_row = discord.ui.ActionRow()
        if state.active_categories:
            auto = discord.ui.Button(label="Auto-create categories", style=discord.ButtonStyle.success, emoji=E_SETUP)
            auto.callback = self._auto_cb
            btn_row.add_item(auto)
        back = discord.ui.Button(label="◀ Back", style=discord.ButtonStyle.secondary, emoji=E_REOPEN)
        back.callback = self._back_cb
        btn_row.add_item(back)
        container.add_item(btn_row)
        self.add_item(container)

    async def _back_cb(self, interaction: discord.Interaction):
        await interaction.response.edit_message(view=SetupStep2Layout(self.state, dropdown=self.dropdown))

    async def _auto_cb(self, interaction: discord.Interaction):
        """Creates a Discord category called '<Label> Tickets' for every button that
        doesn't have one yet. Only staff and the bot can see them."""
        s = self.state
        todo = [n for n in s.active_categories if not s.category_meta.get(n, {}).get("category_id")]
        if not todo:
            return await interaction.response.edit_message(
                view=ButtonCategoryView(s, dropdown=self.dropdown, notice=f"{E_INFO}  Every button already has a category.")
            )
        await interaction.response.defer()
        guild = interaction.guild
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            guild.me: discord.PermissionOverwrite(view_channel=True, manage_channels=True, send_messages=True),
        }
        if s.support_role:
            overwrites[s.support_role] = discord.PermissionOverwrite(view_channel=True, send_messages=True)

        made, failed = [], []
        for name in todo:
            label = _btn_label(s, name)
            try:
                cat = await guild.create_category(
                    f"{label} Tickets"[:100], overwrites=overwrites,
                    reason="E-X: category for button tickets",
                )
                s.category_meta.setdefault(name, {"label": label, "emoji": ""})["category_id"] = cat.id
                made.append(cat.name)
            except discord.HTTPException:
                failed.append(label)

        notice = ""
        if made:
            notice += f"{E_SUCCESS}  Created: {', '.join(made)}"
        if failed:
            notice += f"\n{E_WARN}  Couldn't create (missing **Manage Channels**?): {', '.join(failed)}"
        await interaction.edit_original_response(
            view=ButtonCategoryView(s, dropdown=self.dropdown, notice=notice.strip())
        )


class ButtonCategoryPicker(discord.ui.Select):
    def __init__(self, state: SetupState, *, dropdown: bool):
        self.state    = state
        self.dropdown = dropdown
        super().__init__(
            placeholder="Pick a button to set its category…",
            options=[
                discord.SelectOption(
                    label=_btn_label(state, name)[:100],
                    value=name,
                    emoji=(state.category_meta.get(name, {}).get("emoji") or CATEGORY_EMOJIS.get(name) or None),
                )
                for name in state.active_categories[:25]
            ],
        )

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            view=ButtonCategoryPickView(self.state, self.values[0], dropdown=self.dropdown)
        )


class _CategoryChannelSelect(discord.ui.ChannelSelect):
    def __init__(self, state: SetupState, name: str, *, dropdown: bool):
        self.state    = state
        self.name_key = name
        self.dropdown = dropdown
        super().__init__(
            placeholder="Choose a Discord category…",
            channel_types=[discord.ChannelType.category],
            min_values=1, max_values=1,
        )

    async def callback(self, interaction: discord.Interaction):
        chosen = self.values[0]
        meta = self.state.category_meta.setdefault(
            self.name_key, {"label": self.name_key, "emoji": ""}
        )
        meta["category_id"] = chosen.id
        await interaction.response.edit_message(
            view=ButtonCategoryView(
                self.state, dropdown=self.dropdown,
                notice=f"{E_SUCCESS}  **{_btn_label(self.state, self.name_key)}** tickets will open in {chosen.mention}.",
            )
        )


class ButtonCategoryPickView(discord.ui.LayoutView):
    def __init__(self, state: SetupState, name: str, *, dropdown: bool = False):
        super().__init__(timeout=300)
        self.state    = state
        self.name_key = name
        self.dropdown = dropdown

        container = discord.ui.Container(accent_color=INFO_COLOR)
        container.add_item(discord.ui.TextDisplay(
            f"## {E_VIEW}  {_btn_label(state, name)}\n"
            f"Pick the Discord category where **{_btn_label(state, name)}** tickets should be created.\n"
            f"Currently: {_btn_target(state, name)}"
        ))
        row = discord.ui.ActionRow()
        row.add_item(_CategoryChannelSelect(state, name, dropdown=dropdown))
        container.add_item(row)

        btns = discord.ui.ActionRow()
        reset = discord.ui.Button(label="Use default", style=discord.ButtonStyle.secondary, emoji=E_REOPEN)
        reset.callback = self._reset_cb
        btns.add_item(reset)
        back = discord.ui.Button(label="◀ Back", style=discord.ButtonStyle.secondary)
        back.callback = self._back_cb
        btns.add_item(back)
        container.add_item(btns)
        self.add_item(container)

    async def _reset_cb(self, interaction: discord.Interaction):
        self.state.category_meta.get(self.name_key, {}).pop("category_id", None)
        await interaction.response.edit_message(
            view=ButtonCategoryView(
                self.state, dropdown=self.dropdown,
                notice=f"{E_SUCCESS}  **{_btn_label(self.state, self.name_key)}** will use the default category.",
            )
        )

    async def _back_cb(self, interaction: discord.Interaction):
        await interaction.response.edit_message(view=ButtonCategoryView(self.state, dropdown=self.dropdown))


# ── Button Colour Select (targets a specific button key) ───────

class SingleButtonColorSelect(discord.ui.Select):
    def __init__(self, state: SetupState, target: str, label: str):
        self.state  = state
        self.target = target
        current = state.button_colors.get(target, "Blue")
        super().__init__(
            placeholder=f"Colour for: {label}",
            options=[
                discord.SelectOption(
                    label=c,
                    value=c,
                    description=f"Set {label} to {c}",
                    default=(c == current),
                )
                for c in COLOR_OPTIONS
            ],
        )

    async def callback(self, interaction: discord.Interaction):
        self.state.button_colors[self.target] = self.values[0]
        await interaction.response.send_message(
            view=_ok(f"Colour set to **{self.values[0]}**."), ephemeral=True
        )


class SingleButtonColorView(discord.ui.LayoutView):
    def __init__(self, state: SetupState, target: str, label: str):
        super().__init__(timeout=60)
        container = discord.ui.Container(accent_color=INFO_COLOR)
        container.add_item(discord.ui.TextDisplay(f"{E_INFO}  Choose a colour for **{label}**."))
        row = discord.ui.ActionRow()
        row.add_item(SingleButtonColorSelect(state, target, label))
        container.add_item(row)
        self.add_item(container)


# ── All-buttons colour picker ───────────────────────────────────

class AllButtonsColorSelect(discord.ui.Select):
    """Shows a dropdown to pick which button to recolour."""
    def __init__(self, state: SetupState):
        self.state = state
        options = [
            discord.SelectOption(
                label=f"Main Button ({state.button_label})",
                value="main",
                description=f"Currently: {state.button_colors.get('main', 'Blue')}",
                emoji=E_TICKET,
            )
        ] + [
            discord.SelectOption(
                label=(state.category_meta.get(cat, {}).get("label") or cat)[:100],
                value=cat,
                description=f"Currently: {state.button_colors.get(cat, 'Grey')}",
                emoji=(state.category_meta.get(cat, {}).get("emoji") or CATEGORY_EMOJIS.get(cat) or None),
            )
            for cat in state.active_categories
        ]
        super().__init__(
            placeholder="Which button to recolour?",
            options=options[:25],
        )

    async def callback(self, interaction: discord.Interaction):
        target = self.values[0]
        label  = "Main Button" if target == "main" else target
        await interaction.response.send_message(
            view=SingleButtonColorView(self.state, target, label),
            ephemeral=True,
        )


class AllButtonsColorView(discord.ui.LayoutView):
    def __init__(self, state: SetupState):
        super().__init__(timeout=60)
        container = discord.ui.Container(accent_color=INFO_COLOR)
        container.add_item(discord.ui.TextDisplay(f"{E_INFO}  Pick a button to change its colour."))
        row = discord.ui.ActionRow()
        row.add_item(AllButtonsColorSelect(state))
        container.add_item(row)
        self.add_item(container)


# ── Delete Categories Select ───────────────────────────────────

class DeleteCatsSelect(discord.ui.Select):
    """Lets the admin remove category buttons/options — and, on the button
    panel only, the main 'Open a Ticket' button itself. Guarded so the
    panel can never end up with nothing left to click: removing the main
    button is blocked while zero categories remain, and removing the last
    category is blocked while the main button is already hidden."""

    MAIN_VALUE = "__main_button__"

    def __init__(self, state: SetupState, *, dropdown: bool, parent_message: discord.Message | None):
        self.state          = state
        self.dropdown        = dropdown
        self.parent_message  = parent_message

        options = [
            discord.SelectOption(
                label=(state.category_meta.get(c, {}).get("label") or c)[:100],
                value=c,
                emoji=(state.category_meta.get(c, {}).get("emoji") or CATEGORY_EMOJIS.get(c) or None),
            )
            for c in state.active_categories
        ]
        # The main button is only ever a removable option on the button
        # panel — the dropdown panel has no separate main button.

        super().__init__(
            placeholder="Select what to remove…",
            min_values=1,
            max_values=max(1, len(options)),
            options=options or [discord.SelectOption(label="Nothing left to remove", value="__none__")],
            disabled=not options,
        )

    async def callback(self, interaction: discord.Interaction):
        wants_main = self.MAIN_VALUE in self.values
        cats_to_remove = [v for v in self.values if v != self.MAIN_VALUE]

        # Work out what would remain after this removal, then block the
        # whole action if it would leave the panel with nothing clickable.
        remaining_cats = [c for c in self.state.active_categories if c not in cats_to_remove]
        # If every category is removed, the main button appears again by itself,
        # so the panel is never left empty.
        for cat in cats_to_remove:
            if cat in self.state.active_categories:
                self.state.active_categories.remove(cat)
                self.state.button_colors.pop(cat, None)
                self.state.category_meta.pop(cat, None)
        removed_bits = []
        if cats_to_remove:
            removed_bits.append(", ".join(cats_to_remove))
        if wants_main:
            removed_bits.append("the main button")
        removed_summary = " and ".join(removed_bits)

        remaining = ", ".join(self.state.active_categories) or "None"
        if not self.dropdown:
            remaining += f"  •  Main button: {'hidden' if self.state.active_categories else 'shown (no other buttons)'}"

        # Refresh this ephemeral picker in place so it reflects what's left
        await interaction.response.edit_message(
            view=DeleteCatsView(self.state, dropdown=self.dropdown, parent_message=self.parent_message)
        )

        # Also push the change back to the underlying step-2 panel message,
        # which previously went stale after removing a category from /setup2
        # or /setup.
        if self.parent_message is not None:
            try:
                if self.dropdown:
                    await self.parent_message.edit(view=SetupStep2Layout(self.state, dropdown=True))
                else:
                    await self.parent_message.edit(view=SetupStep2Layout(self.state))
            except discord.HTTPException:
                pass

        await interaction.followup.send(
            view=_ok(f"Removed {removed_summary}. **Remaining:** {remaining}"), ephemeral=True
        )


class DeleteCatsView(discord.ui.LayoutView):
    def __init__(self, state: SetupState, *, dropdown: bool = False, parent_message: discord.Message | None = None):
        super().__init__(timeout=60)
        container = discord.ui.Container(accent_color=INFO_COLOR)
        has_options = bool(state.active_categories)
        text = (
            f"{E_INFO}  Select what to remove."
            if has_options
            else f"{E_WARN}  Nothing left to remove."
        )
        container.add_item(discord.ui.TextDisplay(text))
        row = discord.ui.ActionRow()
        row.add_item(DeleteCatsSelect(state, dropdown=dropdown, parent_message=parent_message))
        container.add_item(row)
        self.add_item(container)


# ── Setup Step 1: Channels & Roles ─────────────────────────────

class _SupportRoleSelect(discord.ui.RoleSelect):
    def __init__(self, state: SetupState):
        self.state = state
        super().__init__(placeholder="① Support Role  (required)", min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        self.state.support_role = self.values[0]
        await interaction.response.send_message(
            view=_ok(f"Support role → {self.state.support_role.mention}"), ephemeral=True
        )


class _PanelChannelSelect(discord.ui.ChannelSelect):
    def __init__(self, state: SetupState):
        self.state = state
        super().__init__(
            placeholder="② Panel Channel  (required)",
            channel_types=[discord.ChannelType.text],
            min_values=1, max_values=1,
        )

    async def callback(self, interaction: discord.Interaction):
        self.state.panel_channel = self.values[0]
        await interaction.response.send_message(
            view=_ok(f"Panel channel → {self.state.panel_channel.mention}"), ephemeral=True
        )


class _TicketCategorySelect(discord.ui.ChannelSelect):
    def __init__(self, state: SetupState):
        self.state = state
        super().__init__(
            placeholder="③ Ticket Category  (required)",
            channel_types=[discord.ChannelType.category],
            min_values=1, max_values=1,
        )

    async def callback(self, interaction: discord.Interaction):
        self.state.ticket_category = self.values[0]
        await interaction.response.send_message(
            view=_ok(f"Ticket category → **{self.state.ticket_category.name}**"), ephemeral=True
        )


class _LogChannelSelect(discord.ui.ChannelSelect):
    def __init__(self, state: SetupState):
        self.state = state
        super().__init__(
            placeholder="④ Log Channel  (optional)",
            channel_types=[discord.ChannelType.text],
            min_values=0, max_values=1,
        )

    async def callback(self, interaction: discord.Interaction):
        self.state.log_channel = self.values[0] if self.values else None
        msg = (
            f"Log channel → {self.state.log_channel.mention}"
            if self.state.log_channel
            else "Log channel skipped."
        )
        await interaction.response.send_message(view=_ok(msg), ephemeral=True)


class SetupStep1Layout(discord.ui.LayoutView):
    def __init__(self, state: SetupState, *, dropdown: bool = False):
        super().__init__(timeout=300)
        self.state    = state
        self.dropdown = dropdown

        container = discord.ui.Container(accent_color=EMBED_COLOR)
        container.add_item(discord.ui.TextDisplay(_step1_text(dropdown=dropdown)))

        for select_cls in (_SupportRoleSelect, _PanelChannelSelect, _TicketCategorySelect, _LogChannelSelect):
            row = discord.ui.ActionRow()
            row.add_item(select_cls(state))
            container.add_item(row)

        btn_row = discord.ui.ActionRow()
        label = "Next — Customise Dropdown Panel" if dropdown else "Next — Customise Panel"
        next_btn = discord.ui.Button(label=label, style=discord.ButtonStyle.primary, emoji=E_SETUP)
        next_btn.callback = self._next_cb
        btn_row.add_item(next_btn)
        container.add_item(btn_row)

        self.add_item(container)

    async def _next_cb(self, interaction: discord.Interaction):
        if not self.state.support_role or not self.state.panel_channel or not self.state.ticket_category:
            return await interaction.response.send_message(
                view=_err("Please select a **Support Role**, **Panel Channel** and **Ticket Category** first."),
                ephemeral=True,
            )
        if self.dropdown:
            await interaction.response.edit_message(view=SetupStep2Layout(self.state, dropdown=True))
        else:
            await interaction.response.edit_message(view=SetupStep2Layout(self.state))


# ── Setup Step 2: Customisation ────────────────────────────────

class SetupStep2Layout(discord.ui.LayoutView):
    """Customisation step shared by /setup (button panel) and /setup2 (dropdown panel)."""
    def __init__(self, state: SetupState, *, dropdown: bool = False):
        super().__init__(timeout=300)
        self.state    = state
        self.dropdown = dropdown

        container = discord.ui.Container(accent_color=EMBED_COLOR)
        container.add_item(discord.ui.TextDisplay(_step2_text(state, dropdown=dropdown)))

        # Row 0 — inside container
        row0 = discord.ui.ActionRow()
        panel_text_btn = discord.ui.Button(label="Panel Text", style=discord.ButtonStyle.primary, emoji=E_CUSTOM)
        panel_text_btn.callback = self._panel_text_cb
        row0.add_item(panel_text_btn)

        footer_media_btn = discord.ui.Button(label="Footer & Media", style=discord.ButtonStyle.primary, emoji=E_VIEW)
        footer_media_btn.callback = self._footer_media_cb
        row0.add_item(footer_media_btn)

        if not dropdown:
            button_label_btn = discord.ui.Button(label="Button Label", style=discord.ButtonStyle.secondary, emoji=E_TICKET)
            button_label_btn.callback = self._button_label_cb
            row0.add_item(button_label_btn)
        container.add_item(row0)

        # Row 1 — inside container
        row1 = discord.ui.ActionRow()
        if not dropdown:
            colour_btn = discord.ui.Button(label="Button Colours", style=discord.ButtonStyle.secondary, emoji=E_INFO)
            colour_btn.callback = self._colour_cb
            row1.add_item(colour_btn)

        add_btn = discord.ui.Button(label="Add Button", style=discord.ButtonStyle.success, emoji=E_SUCCESS)
        add_btn.callback = self._add_category_cb
        row1.add_item(add_btn)

        remove_label = "Remove Button"
        remove_btn = discord.ui.Button(label=remove_label, style=discord.ButtonStyle.danger, emoji=E_DELETE)
        remove_btn.callback = self._remove_category_cb
        row1.add_item(remove_btn)

        cats_btn = discord.ui.Button(label="Button Categories", style=discord.ButtonStyle.secondary, emoji=E_VIEW)
        cats_btn.callback = self._button_categories_cb
        row1.add_item(cats_btn)
        container.add_item(row1)

        # Row 2 — inside container
        row2 = discord.ui.ActionRow()
        back_btn = discord.ui.Button(label="◀ Back", style=discord.ButtonStyle.secondary, emoji=E_REOPEN)
        back_btn.callback = self._back_cb
        row2.add_item(back_btn)

        preview_label = "Preview & Send" if dropdown else "Preview & Finish"
        preview_btn = discord.ui.Button(label=preview_label, style=discord.ButtonStyle.success, emoji=E_SUCCESS)
        preview_btn.callback = self._preview_cb
        row2.add_item(preview_btn)
        container.add_item(row2)

        self.add_item(container)

    async def _panel_text_cb(self, interaction: discord.Interaction):
        await interaction.response.send_modal(PanelTextModal(self.state))

    async def _footer_media_cb(self, interaction: discord.Interaction):
        await interaction.response.send_modal(FooterMediaModal(self.state))

    async def _button_label_cb(self, interaction: discord.Interaction):
        await interaction.response.send_modal(ButtonLabelModal(self.state))

    async def _colour_cb(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            view=AllButtonsColorView(self.state),
            ephemeral=True,
        )

    async def _button_categories_cb(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            view=ButtonCategoryView(self.state, dropdown=self.dropdown)
        )

    async def _add_category_cb(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            view=AddButtonChoiceView(self.state, dropdown=self.dropdown)
        )

    async def _remove_category_cb(self, interaction: discord.Interaction):
        has_anything_to_remove = bool(self.state.active_categories)
        if not has_anything_to_remove:
            return await interaction.response.send_message(
                view=_err("Nothing left to remove."), ephemeral=True
            )
        # Pass the parent (step-2) message through so the select's callback
        # can refresh it after removing categories — previously the panel
        # underneath went stale and Add Category afterwards could even
        # rebuild the wrong panel type from /setup2.
        await interaction.response.send_message(
            view=DeleteCatsView(self.state, dropdown=self.dropdown, parent_message=interaction.message),
            ephemeral=True,
        )

    async def _back_cb(self, interaction: discord.Interaction):
        await interaction.response.edit_message(view=SetupStep1Layout(self.state, dropdown=self.dropdown))

    async def _preview_cb(self, interaction: discord.Interaction):
        if self.dropdown and not self.state.active_categories:
            return await interaction.response.send_message(
                view=_err("Add at least one button first — a dropdown can't be empty."),
                ephemeral=True,
            )
        await interaction.response.edit_message(
            view=PreviewLayout(self.state, dropdown=self.dropdown)
        )


# ── Confirm View ───────────────────────────────────────────────

class PreviewLayout(discord.ui.LayoutView):
    def __init__(self, state: SetupState, *, dropdown: bool = False):
        super().__init__(timeout=120)
        self.state    = state
        self.dropdown = dropdown

        container = discord.ui.Container(accent_color=EMBED_COLOR)
        container.add_item(discord.ui.TextDisplay(_preview_text(state, dropdown=dropdown)))

        row = discord.ui.ActionRow()
        back_btn = discord.ui.Button(label="◀ Back", style=discord.ButtonStyle.secondary, emoji=E_REOPEN)
        back_btn.callback = self._back_cb
        row.add_item(back_btn)

        finish_label = "Send Dropdown Panel" if dropdown else "Finish Setup"
        finish_btn = discord.ui.Button(label=finish_label, style=discord.ButtonStyle.success, emoji=E_SUCCESS)
        finish_btn.callback = self._finish_cb
        row.add_item(finish_btn)
        container.add_item(row)

        self.add_item(container)

    async def _back_cb(self, interaction: discord.Interaction):
        await interaction.response.edit_message(view=SetupStep2Layout(self.state, dropdown=self.dropdown))

    async def _finish_cb(self, interaction: discord.Interaction):
        s = self.state
        bot = interaction.client

        # Resolve defaults
        author_name     = s.resolved_author_name(interaction.guild)
        author_icon_url = s.resolved_author_icon(interaction.guild)
        footer_icon_url = s.resolved_footer_icon(bot)
        thumbnail_url   = s.resolved_thumbnail(interaction.guild)

        existing = get_config(interaction.guild.id) or {}
        config = {
            "support_role_id":    s.support_role.id,
            "panel_channel_id":   s.panel_channel.id,
            "ticket_category_id": s.ticket_category.id,
            "log_channel_id":     s.log_channel.id if s.log_channel else None,
            "ticket_limit":       existing.get("ticket_limit", s.ticket_limit) if self.dropdown else s.ticket_limit,
            "panel_title":        s.panel_title,
            "panel_description":  s.panel_description,
            "author_name":        author_name,
            "author_icon_url":    author_icon_url,
            "footer_text":        s.footer_text,
            "footer_icon_url":    footer_icon_url,
            "thumbnail_url":      thumbnail_url,
            "image_url":          s.image_url,
            "button_label":       existing.get("button_label", s.button_label) if self.dropdown else s.button_label,
            "button_emoji":       existing.get("button_emoji", s.button_emoji) if self.dropdown else s.button_emoji,
            "button_colors":      existing.get("button_colors", s.button_colors) if self.dropdown else s.button_colors,
            "show_main_button":   existing.get("show_main_button", s.show_main_button) if self.dropdown else s.show_main_button,
            "active_categories":  s.active_categories,
            "category_meta":      s.category_meta,
            "form_steps":         existing.get("form_steps", {}),
        }
        set_config(interaction.guild.id, config)

        try:
            if self.dropdown:
                from cogs.tickets import TicketSelectPanel, build_panel_layout

                cats = s.active_categories
                cat_list = "\n".join(
                    f"> {(s.category_meta.get(c, {}).get('emoji') or CATEGORY_EMOJIS.get(c) or '')} "
                    f"**{s.category_meta.get(c, {}).get('label') or c}**".replace(">  **", "> **")
                    for c in cats
                )
                description = f"{s.panel_description}\n\n{cat_list}"
                panel_view = build_panel_layout(
                    guild_name=interaction.guild.name,
                    title=s.panel_title,
                    description=description,
                    color=EMBED_COLOR,
                    author_name=author_name,
                    author_icon_url=author_icon_url,
                    thumbnail_url=thumbnail_url,
                    image_url=s.image_url,
                    action_view=TicketSelectPanel(cats, s.category_meta),
                )
            else:
                from cogs.tickets import TicketPanelView, build_panel_layout

                panel_view = build_panel_layout(
                    guild_name=interaction.guild.name,
                    title=s.panel_title,
                    description=s.panel_description,
                    color=EMBED_COLOR,
                    author_name=author_name,
                    author_icon_url=author_icon_url,
                    thumbnail_url=thumbnail_url,
                    image_url=s.image_url,
                    action_view=TicketPanelView(
                        button_label=s.button_label,
                        button_emoji=s.button_emoji or None,
                        button_color=s.button_colors.get("main", "Blue"),
                        button_colors=s.button_colors,
                        active_categories=s.active_categories,
                        show_main_button=s.show_main_button,
                        category_meta=s.category_meta,
                    ),
                )

            panel_ch = interaction.guild.get_channel(s.panel_channel.id)
            if panel_ch is None:
                panel_ch = await interaction.guild.fetch_channel(s.panel_channel.id)

            await panel_ch.send(view=panel_view)

            if self.dropdown:
                done_text = (
                    f"{E_SUCCESS}  **Dropdown Panel Sent**\n\n"
                    f"Your dropdown panel is live in {panel_ch.mention}.\n\n"
                    f"> {E_VIEW}  Users select a ticket type from a dropdown\n"
                    f"> {E_CUSTOM}  Use `/setform` to configure per-category forms\n"
                    f"> {E_INFO}  Use `/help` for the full command reference"
                )
            else:
                done_text = (
                    f"{E_SUCCESS}  **Setup Complete**\n\n"
                    f"Your ticket system is live in {panel_ch.mention}.\n\n"
                    f"> {E_TICKET}  Button panel sent to the panel channel\n"
                    f"> {E_VIEW}  Use `/setup2` to configure the dropdown panel\n"
                    f"> {E_CUSTOM}  Use `/setform` to configure ticket forms\n"
                    f"> {E_INFO}  Use `/help` for the full command reference"
                )
            await interaction.response.edit_message(view=_ok_raw(done_text))

        except Exception as e:
            await interaction.response.edit_message(view=_err(f"Config saved but failed to send panel: `{e}`"))



# ── Text Builders (Components V2) ──────────────────────────────

def _step1_text(*, dropdown: bool = False) -> str:
    kind = "Dropdown Panel" if dropdown else "Ticket"
    posted_as = "dropdown panel" if dropdown else "button panel"
    return (
        f"## {E_SETUP}  {kind} Setup — Step 1 of 2\n"
        f"Configure your channels and roles below.\n\n"
        f"**{E_CLAIM}  Required**\n"
        f"> **①** Support Role — who can manage tickets\n"
        f"> **②** Panel Channel — where the {posted_as} is posted\n"
        f"> **③** Ticket Category — where ticket channels open\n\n"
        f"**{E_INFO}  Optional**\n"
        f"> **④** Log Channel — where ticket events are logged\n\n"
        f"Fill in the required fields then click **Next**."
    )


def _step2_text(state: SetupState, *, dropdown: bool = False) -> str:
    cats = ", ".join(state.active_categories) or (
        "None — add at least one" if dropdown else "None (only the Open a Ticket button)"
    )
    kind = "Dropdown Panel" if dropdown else "Ticket"
    lines = [
        f"## {E_CUSTOM}  {kind} Setup — Step 2 of 2",
        "Customise your panel below.\n",
        f"> {E_CUSTOM}  **Panel Text** — title, description, author name & icon",
        f"> {E_VIEW}  **Footer & Media** — footer, thumbnail, banner",
    ]
    if not dropdown:
        lines.append(f"> {E_TICKET}  **Button Label** — main button label & emoji")
        lines.append(f"> {E_INFO}  **Button Colours** — colour for every button on the panel")
    if dropdown:
        lines.append(f"> {E_SUCCESS}  **Add Button** — add a dropdown option (name, label, emoji)")
    else:
        lines.append(f"> {E_SUCCESS}  **Add Button** — add a custom button (name, label, emoji, colour)")
    if dropdown:
        lines.append(f"> {E_DELETE}  **Remove Button** — remove a dropdown option")
    else:
        lines.append(f"> {E_DELETE}  **Remove Button** — remove a custom button, or the main button")
    lines.append(f"> {E_VIEW}  **Button Categories** — choose which Discord category each button's tickets go in")
    lines.append(f"\n**{'Dropdown Options' if dropdown else 'Custom Buttons'}:** {cats}")
    if not dropdown:
        lines.append(f"**Main Button:** {'Hidden (category buttons used)' if state.active_categories else 'Shown (no other buttons)'}")
    if not dropdown:
        colors_preview = "  ".join(
            f"`{k}: {v}`" for k, v in state.button_colors.items()
            if k == "main" or k in state.active_categories
        )
        lines.append(f"**Colours:** {colors_preview or 'defaults'}")
    finish_label = "Preview & Send" if dropdown else "Preview & Finish"
    lines.append(f"\nClick **{finish_label}** when ready.")
    return "\n".join(lines)


def _preview_text(s: SetupState, *, dropdown: bool = False) -> str:
    kind = "Dropdown Panel" if dropdown else "Button Panel"
    finish_label = "Send Dropdown Panel" if dropdown else "Finish Setup"

    lines = [
        f"## {E_VIEW}  {kind} — Preview",
        f"Review your settings then click **{finish_label}**.\n",
        f"> **Panel Channel:** {s.panel_channel.mention}",
        f"> **Support Role:** {s.support_role.mention}",
        f"> **Ticket Category:** {s.ticket_category.name}",
        f"> **Log Channel:** {s.log_channel.mention if s.log_channel else 'None'}",
        f"> **Panel Title:** {s.panel_title}",
        f"> **Author Name:** {s.author_name or '(server name)'}",
        f"> **Footer Text:** {s.footer_text}",
        f"> **Thumbnail:** {f'{E_SUCCESS} Set' if s.thumbnail_url else '(server icon)'}",
        f"> **Banner Image:** {f'{E_SUCCESS} Set' if s.image_url else 'None'}",
        f"> **{'Dropdown Options' if dropdown else 'Custom Buttons'}:** {', '.join(s.active_categories) or 'None'}",
    ]
    mapped = [f"{_btn_label(s, n)} → {_btn_target(s, n)}" for n in s.active_categories if s.category_meta.get(n, {}).get("category_id")]
    if mapped:
        lines.append(f"> **Ticket Categories:** {'; '.join(mapped)}")
    if not dropdown:
        lines.append(f"> **Main Button:** {'Hidden (category buttons used)' if s.active_categories else 'Shown (no other buttons)'}")
    if not dropdown:
        colors_text = "  ".join(
            f"`{k}: {v}`" for k, v in s.button_colors.items()
            if k == "main" or k in s.active_categories
        ) or "defaults"
        lines.append(f"> **Button Colours:** {colors_text}")
    return "\n".join(lines)


# ── Cog ───────────────────────────────────────────────────────

class SetupCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="setup", description="Configure the E-X ticket button panel")
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    async def setup(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message(
                view=_err("You need the **Administrator** permission."), ephemeral=True
            )
        existing = get_config(interaction.guild.id) or {}
        state = SetupState()
        state.show_main_button   = existing.get("show_main_button", True)
        await interaction.response.send_message(
            view=SetupStep1Layout(state, dropdown=False), ephemeral=True
        )

    @app_commands.command(name="setup2", description="Configure and send the dropdown ticket panel")
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    async def setup2(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message(
                view=_err("You need the **Administrator** permission."), ephemeral=True
            )
        # Pre-load existing config if available
        existing = get_config(interaction.guild.id) or {}
        state = SetupState()
        state.panel_title       = existing.get("panel_title", "Support Center")
        state.panel_description = existing.get("panel_description", "Select a ticket type from the menu below.")
        state.author_name       = existing.get("author_name", "")
        state.author_icon_url   = existing.get("author_icon_url", "")
        state.footer_text       = existing.get("footer_text", "E-X")
        state.footer_icon_url   = existing.get("footer_icon_url", "")
        state.thumbnail_url     = existing.get("thumbnail_url", "")
        state.image_url         = existing.get("image_url", DEFAULT_BANNER)
        if "standard_2.gif" in state.image_url:  # old default banner from earlier versions
            state.image_url = ""
        # Nothing preselected — same as /setup. Add buttons yourself.
        state.active_categories = []
        state.category_meta     = {}
        await interaction.response.send_message(
            view=SetupStep1Layout(state, dropdown=True), ephemeral=True
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(SetupCog(bot))
