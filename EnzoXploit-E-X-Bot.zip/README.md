# E-X Bot

A multi-purpose Discord bot by **EnzoXploit** — tickets, welcome messages, announcements.
(discord.py 2.7+, Python 3.10+). © 2026 EnzoXploit — MIT License, see `LICENSE`.

## Setup
1. Create a bot at https://discord.com/developers/applications → **Bot** tab.
   Turn on **Server Members Intent** and **Message Content Intent**.
2. Invite it with scopes `bot` + `applications.commands`.
3. Copy `.env.example` to `.env` and put your token in it: `TOKEN=your_bot_token_here`
4. Run:
   ```bash
   pip install -r requirements.txt
   python main.py
   ```

### Termux (Android)
```bash
pkg update -y && pkg install -y python unzip nano clang libffi openssl
cd EnzoXploit-E-X-Bot
pip install -r requirements.txt
cp .env.example .env && nano .env
python main.py
```
Stop with `Ctrl+C`.

## Tickets
Channels are named `🎭┃ticket-0001`. Claiming does not rename the channel.
Staff press **Finish** → the channel becomes `✅┃ticket-0001` and a
"marked as finished by @moderator" message is posted.

## Commands
| Command | What it does | Permission |
|---|---|---|
| `/welcome setup` | Welcome message + optional auto-role, banner, ping | Manage Server |
| `/welcome test` · `status` · `disable` | Preview / view / turn off welcome | Manage Server |
| `/say` | Bot sends a message (optional @everyone/@here/role ping) | Manage Server |
| `/announce` | Styled announcement with title, text, image and ping | Manage Server |
| `/setup`, `/setup2`, `/panel2`, `/setform` | Ticket panels and forms | Administrator |
| `/close` `/add` `/remove` `/transcript` `/ticketinfo` | Manage a ticket | Support role |
| `/help` | Help | Everyone |

Welcome placeholders: `{user}` `{username}` `{server}` `{count}`.

## Data
Everything is stored in one SQLite file: `data/enzo.db` (built into Python, nothing to install). To back up, copy `data/enzo.db`.

Never share your `.env` file or token.
