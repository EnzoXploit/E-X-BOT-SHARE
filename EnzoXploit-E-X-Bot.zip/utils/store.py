"""
Storage utility — E-X (SQLite)
Dev: EnzoXploit

Everything lives in one file: data/enzo.db  (Python's built-in sqlite3, nothing to install).
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

DATA_DIR = Path(__file__).parent.parent / "data"
DB_FILE  = DATA_DIR / "enzo.db"

_lock = threading.RLock()
_conn: sqlite3.Connection | None = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS configs (
    guild_id TEXT PRIMARY KEY,
    data     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS welcome (
    guild_id TEXT PRIMARY KEY,
    data     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS counters (
    guild_id TEXT PRIMARY KEY,
    last     INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS tickets (
    channel_id  TEXT PRIMARY KEY,
    guild_id    TEXT NOT NULL,
    author_id   TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'open',
    finished_by TEXT,
    number      INTEGER NOT NULL DEFAULT 0,
    data        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tickets_user  ON tickets (guild_id, author_id, status);
CREATE INDEX IF NOT EXISTS idx_tickets_guild ON tickets (guild_id);
"""


# ── Connection ─────────────────────────────────────────────────

def _db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        with _lock:
            if _conn is None:
                DATA_DIR.mkdir(exist_ok=True)
                conn = sqlite3.connect(DB_FILE, check_same_thread=False, isolation_level=None)
                conn.row_factory = sqlite3.Row
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")
                conn.execute("PRAGMA foreign_keys=ON")
                conn.executescript(SCHEMA)
                _conn = conn
    return _conn


def close_db():
    """Optional: call on shutdown."""
    global _conn
    with _lock:
        if _conn is not None:
            _conn.close()
            _conn = None


def _dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False)


# ── Guild Configs ──────────────────────────────────────────────

def get_config(guild_id: int) -> dict | None:
    with _lock:
        row = _db().execute("SELECT data FROM configs WHERE guild_id=?", (str(guild_id),)).fetchone()
    return json.loads(row["data"]) if row else None


def all_configs() -> dict:
    with _lock:
        rows = _db().execute("SELECT guild_id, data FROM configs").fetchall()
    return {r["guild_id"]: json.loads(r["data"]) for r in rows}


def set_config(guild_id: int, config: dict):
    with _lock:
        _db().execute("INSERT OR REPLACE INTO configs VALUES (?, ?)", (str(guild_id), _dumps(config)))


# ── Ticket Records ─────────────────────────────────────────────

def _save_ticket(channel_id: int | str, t: dict):
    _db().execute(
        "INSERT OR REPLACE INTO tickets "
        "(channel_id, guild_id, author_id, status, finished_by, number, data) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (str(channel_id), str(t.get("guild_id", "")), str(t.get("author_id", "")),
         t.get("status", "open"), t.get("finished_by") or None,
         int(t.get("number", 0) or 0), _dumps(t)),
    )


def get_ticket(channel_id: int) -> dict | None:
    with _lock:
        row = _db().execute("SELECT data FROM tickets WHERE channel_id=?", (str(channel_id),)).fetchone()
    return json.loads(row["data"]) if row else None


def get_user_open_count(guild_id: int, user_id: int) -> int:
    with _lock:
        row = _db().execute(
            "SELECT COUNT(*) AS n FROM tickets WHERE guild_id=? AND author_id=? AND status='open'",
            (str(guild_id), str(user_id)),
        ).fetchone()
    return row["n"]


def get_user_open_ticket_ids(guild_id: int, user_id: int) -> list[str]:
    """Channel IDs of this user's tickets that still count as open
    (finished tickets don't block opening a new one)."""
    with _lock:
        rows = _db().execute(
            "SELECT channel_id FROM tickets WHERE guild_id=? AND author_id=? AND status='open' "
            "AND (finished_by IS NULL OR finished_by='')",
            (str(guild_id), str(user_id)),
        ).fetchall()
    return [r["channel_id"] for r in rows]


def next_ticket_number(guild_id: int) -> int:
    """Next ticket number for this server: 1, 2, 3, 4 …

    Remembered in the database, so numbers keep counting up even after tickets
    are closed or deleted. The highest ticket still on record is used as a
    floor. Done in one transaction, so two tickets can never get the same number."""
    key = str(guild_id)
    with _lock:
        conn = _db()
        conn.execute("BEGIN IMMEDIATE")
        try:
            row = conn.execute("SELECT last FROM counters WHERE guild_id=?", (key,)).fetchone()
            top = conn.execute(
                "SELECT COALESCE(MAX(number), 0) AS m FROM tickets WHERE guild_id=?", (key,)
            ).fetchone()["m"]
            number = max(row["last"] if row else 0, top) + 1
            conn.execute("INSERT OR REPLACE INTO counters VALUES (?, ?)", (key, number))
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    return number


def create_ticket(channel_id: int, data: dict):
    with _lock:
        _save_ticket(channel_id, {**data, "status": "open", "created_at": time.time()})


def update_ticket(channel_id: int, updates: dict):
    with _lock:
        row = _db().execute("SELECT data FROM tickets WHERE channel_id=?", (str(channel_id),)).fetchone()
        if not row:
            return
        t = json.loads(row["data"])
        t.update(updates)
        _save_ticket(channel_id, t)


def delete_ticket(channel_id: int):
    with _lock:
        _db().execute("DELETE FROM tickets WHERE channel_id=?", (str(channel_id),))


# ── Welcome Config ─────────────────────────────────────────────

def get_welcome(guild_id: int) -> dict | None:
    with _lock:
        row = _db().execute("SELECT data FROM welcome WHERE guild_id=?", (str(guild_id),)).fetchone()
    return json.loads(row["data"]) if row else None


def set_welcome(guild_id: int, config: dict):
    with _lock:
        _db().execute("INSERT OR REPLACE INTO welcome VALUES (?, ?)", (str(guild_id), _dumps(config)))
