"""
Branding — footer used by every panel, log, DM and info message.

The footer shows the SERVER's name:
    ticket system   -> '<Server> Ticketing • Powered by EnzoXploit'
    welcome system  -> '<Server> Welcoming • Powered by EnzoXploit'
    everything else -> '<Server> • Powered by EnzoXploit'
If there is no server (e.g. a DM) it falls back to 'E-X'.
"""
from __future__ import annotations

import discord

BRAND   = "E-X"
POWERED = "Powered by EnzoXploit"
FOOTER_TEXT = f"{BRAND} • {POWERED}"


def footer_text(kind: str = "", guild_name: str = "") -> str:
    name  = (guild_name or BRAND).strip()
    label = f"{name} {kind}".strip()
    return f"{label} • {POWERED}"


def footer_item(extra: str = "", kind: str = "", guild_name: str = "") -> discord.ui.TextDisplay:
    """Footer line, e.g. '-# ZeTroX Ticketing • Powered by EnzoXploit'.
    `extra` is optional additional small text shown above the brand line."""
    line = footer_text(kind, guild_name)
    text = f"-# {extra}\n-# {line}" if extra else f"-# {line}"
    return discord.ui.TextDisplay(text)


def add_footer(container: discord.ui.Container, extra: str = "", kind: str = "", guild_name: str = "") -> None:
    container.add_item(discord.ui.Separator())
    container.add_item(footer_item(extra, kind, guild_name))
